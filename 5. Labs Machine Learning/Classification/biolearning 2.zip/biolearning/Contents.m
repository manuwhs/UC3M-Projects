% Bioinformatics Toolbox -- Statistical Learning functions.

%   Copyright 2003-2004 The MathWorks, Inc. 

