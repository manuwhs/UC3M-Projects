function display(cp)
%DISPLAY command window display.

% Copyright 2003-2004 The MathWorks, Inc.


get(cp)
