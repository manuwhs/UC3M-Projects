function schema
%

% Copyright 2003-2004 The MathWorks, Inc.

schema.package('biolearning');
