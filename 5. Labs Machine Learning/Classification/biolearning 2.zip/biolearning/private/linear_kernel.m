function K = linear_kernel(u,v,varargin) 
%LINEAR_KERNEL Linear kernel for SVM functions

% Copyright 2004-2012 The MathWorks, Inc.
% $Revision: 1.1.12.5 $  $Date: 2012/05/03 23:56:58 $
K = (u*v');
