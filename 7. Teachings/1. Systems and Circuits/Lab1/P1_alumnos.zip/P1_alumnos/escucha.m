function escucha(x)
fs = 11025;
sound(x, fs);