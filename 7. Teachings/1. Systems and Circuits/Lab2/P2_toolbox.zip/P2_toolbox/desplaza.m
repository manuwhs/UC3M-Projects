function [ xd, nd ] = desplaza(x,n,d)
%DESP Summary of this function goes here
%   Detailed explanation goes here
    xd = x;
    nd = n - d;
    
end

