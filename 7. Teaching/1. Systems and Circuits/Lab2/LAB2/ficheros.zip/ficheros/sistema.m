function [ny, y] = sistema(nx, x)

% Implementa el sistema descrito mediante la ecuacion
% y[n] = x[n+1]^2 + sin(x[n]) - x[2n]
% 
% Entradas:
% nx: rango de instantes de tiempo en los que se define la sennal
% de entrada
% x: valores de la sennal de entrada
%
% Salidas:
% ny: rango de instantes de tiempo en los que se define la sennal
% de salida
% y: valores de la sennal de salida

% N�mero de muestras de x
N = length(x);

% Construccion de los ejes de tiempos
% Si la sennal x[n] esta definida entre nx(1) y nx(end), el primer 
% t�rmino no nulo de la se�al de salida corresponde al instante nx(1)-1
% por el t�rmino en n+1.
% De igual modo, el �ltimo instante para el que tendremos salida 
% no nula es nx(end) por el termino en n de la ecuacion.
% Definimos los valores de n de interes teniendo en cuenta lo anterior
ny = nx(1)-1 : nx(end);

% Termino x[n+1]^2
x1 = [x, 0];
y1 = x1.^2;

% Termino cos(x[n])
x2 = [0, x];
y2 = sin(x2);

% Termino - x[2n]: 
x3 = [0, x, zeros(1,N)];
y3 = -x3(1:2:end);

% La salida es la suma de las 3 componentes
y = y1 + y2 + y3;

